# ! /bin/bash
# Programa para ejemplificar el uso de la descarga de información desde internet utilizando el comando wget
# Autor: marcelo contreras

echo "Descargar información de internet"
wget https://eeo.eaoe.cc/fa89ff46066acbd1887fd1400867ff6f/wFPPunMQbdU