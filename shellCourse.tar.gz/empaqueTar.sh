# ! /bin/bash
# Programa para ejemplificar empaquetar  archivos  TAR
# Autor: marcelo contreras

echo "Empaquetar todos los scripts de la carpeta shellCourse"
tar -cvf shellCourse.tar *.sh